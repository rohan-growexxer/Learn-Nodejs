const User = require('../models/Hotel');
const bcrypt = require('bcryptjs');